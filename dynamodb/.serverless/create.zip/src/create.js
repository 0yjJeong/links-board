/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 536:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.create = void 0;
const short_uuid_1 = __importDefault(__webpack_require__(978));
const dynamoClient_1 = __importDefault(__webpack_require__(908));
const TableName = process.env.DYNAMO_TABLE || '';
const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Origin': '*',
};
const createHandler = (body) => __awaiter(void 0, void 0, void 0, function* () {
    let parsedBody = {};
    if (body) {
        try {
            const parsed = JSON.parse(body);
            parsedBody = parsed || {};
        }
        catch (e) {
            const response = {
                body: JSON.stringify({
                    input: body,
                    message: 'Melformed body',
                }),
                headers,
                statusCode: 500,
            };
            return { response, error: null };
        }
    }
    if (parsedBody !== '' && typeof parsedBody === 'object') {
        try {
            const id = (0, short_uuid_1.default)().new();
            const params = {
                Item: Object.assign({ id }, parsedBody),
                TableName,
            };
            yield dynamoClient_1.default.put(params).promise();
            const response = {
                body: JSON.stringify(params.Item),
                headers: headers,
                statusCode: 200,
            };
            return { response, error: null };
        }
        catch (error) {
            const response = {
                body: JSON.stringify(error),
                headers,
                statusCode: 500,
            };
            return { response, error };
        }
    }
    else {
        const response = {
            body: JSON.stringify({
                input: body,
                message: 'Bad input data or missing text',
            }),
            headers,
            statusCode: 422,
        };
        return { response, error: null };
    }
});
const create = (event, _, callback) => {
    return createHandler(event.body).then(({ response, error }) => {
        if (error) {
            callback && callback(error);
        }
        else {
            callback && callback(null, response);
        }
    });
};
exports.create = create;


/***/ }),

/***/ 908:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const aws_sdk_1 = __webpack_require__(336);
let options = {};
if (false) {}
const dynamoClient = new aws_sdk_1.DynamoDB.DocumentClient(options);
exports["default"] = dynamoClient;


/***/ }),

/***/ 336:
/***/ ((module) => {

module.exports = require("aws-sdk");

/***/ }),

/***/ 978:
/***/ ((module) => {

module.exports = require("short-uuid");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(536);
/******/ 	module.exports = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=create.js.map